package com.cts.main.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.cts.buyer.entity.BuyerInfo;
//import com.cts.buyer.entity.CartItems;
//import com.cts.buyer.entity.Item;
//import com.cts.buyer.entity.PurchaseHistory;
//import com.cts.buyer.entity.TransactionHistory;
import com.cts.main.buyer.BuyerLogin;
import com.cts.main.buyer.CartItem;
import com.cts.main.buyer.ProductDetail;
import com.cts.main.buyer.PurchaseHistory;
import com.cts.main.buyer.TransactionsHistory;
import com.cts.main.repo.BuyerRepositary;
import com.cts.main.repo.CartRespositary;
import com.cts.main.repo.ProductRepositary;
import com.cts.main.repo.PurchaseHistoryRepository;
import com.cts.main.repo.TransactionHistoryRepository;



@Service
public class CartService{

@Autowired
private CartRespositary cartrepositary;
@Autowired
private BuyerRepositary buyerrepositary;
@Autowired
private ProductRepositary productrepositary;

@Autowired
private TransactionHistoryRepository transactionHistoryRepository;
@Autowired
private PurchaseHistoryRepository purchaseHistoryRepository;
 

public CartItem addcartitem(CartItem cartItem, Integer buyerId) {
	  
	    Optional<BuyerLogin> buyer = buyerrepositary.findById(buyerId);
	    cartItem.setBuyerinfo(buyer.get());
	    return cartrepositary.save(cartItem);
	    
	    
}
	
    public String deletecartItem(Integer cartItemId) {
    	cartrepositary.deleteById(cartItemId);
    	return "deleted that cartItemId";
    }
    
    public List<CartItem> getallCartItem(Integer buyerId){
    	List<CartItem> AllItems = cartrepositary.getlistcartitem(buyerId);
    	return AllItems;
    	
    }
    
    public String emptyCartItem(Integer buyerId) {
    	cartrepositary.deleteAll();
    	return "Cart is Empty";
    }
     
    
   public CartItem updateCartItem(Integer cartItemId, CartItem cartItem){
	    Optional<CartItem> upadteItem=cartrepositary.findById(cartItemId);
	     if(upadteItem.isPresent())
	     {
	                CartItem Itemupdate=upadteItem.get();    
	                Itemupdate.setQuantity(cartItem.getQuantity());
	                return cartrepositary.save(Itemupdate);
	     }
	     return null;
   }
   
   
   public void checkout(Integer buyerId) {
	   Double totalAmount=0.00;
	   
	   List<CartItem> cartitem=cartrepositary.getlistcartitem(buyerId);
	   for(CartItem items:cartitem) {
		    Optional<ProductDetail>item= productrepositary.findById(items.getCartItemId());
		    totalAmount=totalAmount+item.get().getPrice();}
		    
		    Optional<BuyerLogin> buyer=buyerrepositary.findById(buyerId);{
		     TransactionsHistory transaction=new TransactionsHistory();
		     transaction.setBuyer(buyer.get());
		     transaction.setTransactionAmount(totalAmount);
		     transaction.setRemarks("successful");
		     transaction.setTransactionType("debit card");
		    transactionHistoryRepository.save(transaction);
		    for(CartItem items:cartitem) {
		    	PurchaseHistory purchase=new PurchaseHistory();
		    	purchase.setBuyerinfo(buyer.get());
		    	purchase.setTransaction(transaction);
		    	purchase.setItemId(items.getItemId());
		    	purchase.setNumberOfItems(items.getQuantity());
		    	purchaseHistoryRepository.save(purchase);
		    	
		    }	
		    
		    }   
   }
}
		    
		     
		    
		    
		    
		    
	   
	   
   

	    
	    
	    	
	    	
	    
   
  
 

  
   



