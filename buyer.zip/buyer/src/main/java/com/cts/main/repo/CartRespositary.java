package com.cts.main.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cts.main.buyer.CartItem;

@Repository
public interface CartRespositary extends JpaRepository<CartItem, Integer> {
	
    @Query(value= "SELECT * FROM cart_item item WHERE item.buyerinfo_buyer_id = :buyerId", nativeQuery = true)
	public List<CartItem> getlistcartitem(@Param("buyerId") Integer buyerId);
    
    

}
