``
var nameExpression =/^[a-zA-Z]+$/;
var numbers = /^[0-9]+$/;
function formValidation()
{
if(firstNameValidation())
{
	if(lastNameValidation())
	{
		if(ageValidation())
		{	
			if(emailValidate())
			{ 
				if(validateNumber())
				{
					if(validatePincode())
					{
						return true;
					}
				}	 
			}
		}
	}
}
return false;
}

function firstfocus()
	{
  		var fname = document.appointment.Firstname.focus();
  		return true;
  	}


function firstNameValidation()
	{
		 var firstName = document.getElementById("firstname");
		 var nameLength = firstName.vlaue.length;
		 if(nameExpression.test(Firstname) == false || nameLength == 0)
		 {
		 	
		 	alert("Enter valid name");
		 	return false;
		 }
		 document.appointment.Lastname.focus();
		 return true;
	}

function lastNameValidation()
	{
		 var lastName = document.getElementById("lastname");
		 var nameLength = lastName.vlaue.length;
		 if(nameExpression.test(lastName) == false || nameLength == 0)
		 {
		 	lastName.focus();
		 	error("Enter valid name");
		 	return false;
		 }
		 document.appointment.age.focus();
		 return true;
	}
function emailValidate()
  	{
  		var uemail = document.appointment.email;
  		var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  		if(uemail.test(mailformat) == true)
  		{
  			document.appointment.name.focus();
 			return true;
  		}
 	 	else
  		{
  			error("Enter valid Email");
  			uemail.focus();
  			return false;
 		}
 	}
function validateNumber()
	{

		var moblieNumber = documnet.getElementById("Phno");
		for (var i = 1; i < moblieNumber.length; i++) 
		{
			if(moblieNumber[i].test(numbers) == false)
			{
				error("Enter valid moblile number");
				moblieNumber.focus();
				return false;
			}
		}
		documnet.appointment.pincode.focus();
		return true;
	}
function validatePincode()
  	{ 
  		var uPinCode = document.appointment.zip;
  		if(uPinCode.test(numbers) == true)
  		{
  			document.getElementById("submitbutton").focus();
  			return true;
  		}
  		else
  		{
  			error("enter valid Pincode");
  			uPinCode.focus();
  			return false;
  		}
  	}
