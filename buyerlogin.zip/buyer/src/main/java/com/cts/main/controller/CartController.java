package com.cts.main.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.main.buyer.CartItem;
import com.cts.main.service.CartService;

@RestController
@CrossOrigin("*")
public class CartController {
	@Autowired
	private CartService cartservice;
	@PostMapping(value="/{buyerId}/addcartitem")
	public CartItem addcartItem(@PathVariable(value= "buyerId") Integer buyerId,@RequestBody CartItem cartItem) {
		return cartservice.addcartitem(cartItem, buyerId);
	}
	@GetMapping(value="{buyerId}/getallcartItem")
	public List<CartItem> getallCartItem(@PathVariable(value="buyerId") Integer buyerId){
		return cartservice.getallCartItem(buyerId);
		
	}
	
	@DeleteMapping(value= "/{cartItemId}/deletebyid")
	public void deletecartItem(@PathVariable(value="cartItemId")Integer cartItemId){
		cartservice.deletecartItem(cartItemId);
	}
	
	@PutMapping(value="/updatecartItem" )
	public CartItem updatecartItem(@RequestBody CartItem cartItem){
		return cartservice.updateCartItem(cartItem.getCartItemId(),cartItem);
	}
	
	@DeleteMapping(value = "/{buyerId}/deleteall")
	public String deleteAllItems(@PathVariable(value = "buyerId") Integer buyerId) {
		return cartservice.emptyCartItem(buyerId);
	}
	
	@PostMapping(value="/{buyerId}/checkout")
	public void checkout(@PathVariable(value = "buyerId") Integer buyerId) {
		System.out.println(buyerId);
		 cartservice.checkout(buyerId);

}
	
}

