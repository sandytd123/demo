package com.cts.main.buyer;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class CartItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer cartItemId;
	private Integer itemId;
	private Integer quantity;
	private Integer price;
	@OneToOne
	private BuyerLogin buyerinfo;
	
	public CartItem()
	{
		
	}

	public CartItem(Integer cartItemId, Integer itemId, Integer quantity, Integer price, BuyerLogin buyerinfo) {
		super();
		this.cartItemId = cartItemId;
		this.itemId = itemId;
		this.quantity = quantity;
		this.price = price;
		this.buyerinfo = buyerinfo;
	}

	public Integer getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Integer cartItemId) {
		this.cartItemId = cartItemId;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public BuyerLogin getBuyerinfo() {
		return buyerinfo;
	}

	public void setBuyerinfo(BuyerLogin buyerinfo) {
		this.buyerinfo = buyerinfo;
	}

	@Override
	public String toString() {
		return "CartItem [cartItemId=" + cartItemId + ", itemId=" + itemId + ", quantity=" + quantity + ", price="
				+ price + ", buyerinfo=" + buyerinfo + "]";
	}
	
}


	