package com.cts.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.main.buyer.BuyerLogin;
@Repository
public interface BuyerRepositary extends JpaRepository<BuyerLogin, Integer>{
	public BuyerLogin findByUsername(String username);
}
