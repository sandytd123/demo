package com.cts.control;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	List<Model> list=new ArrayList();
	Map<Integer,Model> m1=new HashMap();
	@RequestMapping("/")
	public String addmethod() {
		return "hello";
		 
	}
	@RequestMapping("/json")
	//public List<Model> addmethod1() {
		//String s="{\"success\":\"name\",\"report\":\"time\"}";
	   // return list;
	public Map<Integer, Model> addmethod1(){
		return m1;
	}
	
	public HomeController()
	
	{
		list.add(new Model(1000,"tv",10,11));
		list.add(new Model(1001,"ac",11,101));
		m1.put(1001, new Model(1220,"tv",12300,2));
		m1.put(1002, new Model(1221,"washing",1200,5));
		
	}
	 @RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Model getbyid(@PathVariable("id") int prodid)
	{
		// return m1.get(prodid) ;
		return list.get(prodid);
		
	}
	 
	
}

