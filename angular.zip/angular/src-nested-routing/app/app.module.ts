import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { routes } from './app.routes';
import { AppComponent } from './app.component';
import { AboutComponent } from './about.component';
import { AboutItemComponent } from './about.item.component';
import { AboutHomeComponent } from './about.home.component';
import { HomeComponent } from './home.component';
import { HelpComponent } from './help.component';
import {HelpUserComponent} from './helpuser.component';
import { HelpAdminComponent } from './helpadmin.component';


@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [
    AboutComponent,
    AboutItemComponent,
    AboutHomeComponent,
    HomeComponent,
    HelpComponent,
    HelpUserComponent,
    HelpAdminComponent,
    AppComponent
  ],
  providers: [ ],
  bootstrap: [ AppComponent ]
})
export class AppModule {
}
