import {BrowserModule} from '@angular/platform-browser';
import {NgModule}      from '@angular/core';

import {AppComponent}  from './app.component';
import { MathematicsService } from './services/maths.service';
import { LoggingService } from './services/logging.service';


@NgModule({
  imports: [     
        BrowserModule
  ],
  declarations: [
        AppComponent
  ],
  providers: [
      MathematicsService, 
      LoggingService
  ],
  bootstrap: [
        AppComponent
  ]
})
export class AppModule { }
