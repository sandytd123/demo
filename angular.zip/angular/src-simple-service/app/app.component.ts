import { Component } from '@angular/core';  
import {MathematicsService} from './services/maths.service'; 
import {LoggingService} from './services/logging.service';

@Component({  
  selector: 'app-root',  
  templateUrl: './app.component.html'
})  
  export class AppComponent {  

    lservice:LoggingService;
    
    constructor(ls: LoggingService){
      this.lservice = ls;
      this.writeOut();
    }

  writeOut():void{   
    this.lservice.funLog();
  }  
}