import {Component} from '@angular/core';
import {Observable} from 'rxjs/Observable';

@Component({
    selector: 'app-root',
	template: `
	  <b>Angular 2 Component Using Observables!</b>
	 
	  <h6 style="margin-bottom: 0">VALUES:</h6>
      <div *ngFor="let value of values">- {{ value }}</div>
      <!-- values gets updated dynamically with data items-->
	  
	  <h6 style="margin-bottom: 0">ERRORs:</h6>
	  <div>Errors: {{anyErrors}}</div>
	  
	  <h6 style="margin-bottom: 0">FINISHED:</h6>
	  <div>Finished: {{ finished }}</div>
	  
      <button style="margin-top: 2rem;" (click)="init()">Init</button><br>
      <button style="margin-top: 2rem;" (click)="cancelit()">Cancel It</button>
	`
})
export class AppComponent {
  private data: Observable<number>;
  private values: Array<number> = []; //values received dynamically
  private anyErrors: boolean; //if errors, this is set to trow by lambda expression
  private finished: boolean;
  private subscription: any;   
  constructor() {
  }

  init() {
      this.data = new Observable(observer => {
          setTimeout(() => {
              observer.next(42);
          }, 4000);

          setTimeout(() => {
              observer.next(43);
          }, 3000);

          setTimeout(() => {
              observer.complete();
          }, 8000);

          /*setTimeout(() => {
            observer.next(43);
        }, 8100);*/

      });

      this.subscription = this.data.subscribe(
          value => this.values.push(value),//lambda expression
          error => this.anyErrors = true,
          () => this.finished = true
      );

  }

//this can be invoked when User cancels, any operation like retrieval of data, etc...
  cancelit(): void {
    this.subscription.unsubscribe();

  }
}
