import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { MessageComponent } from './app.component';


@NgModule({
  declarations: [
    MessageComponent  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [MessageComponent]
})
export class AppModule { }
