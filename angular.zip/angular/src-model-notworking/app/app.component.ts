import {Component} from '@angular/core';
import {User} from './user';
@Component({
    selector: 'user-app',
    templateUrl: 'app.component.html' 
	
})
export class AppComponent {
	users = [
      new User('Mahesh', 20),
      new User('Krishna', 22),
      new User('Narendra', 30)
    ];
 }
 