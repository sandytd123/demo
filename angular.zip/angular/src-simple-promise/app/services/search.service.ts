import { Http, HttpModule } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class SearchService {

  constructor(private http: Http) {}

  search(term: string) {
    return this.http
      .get(`http://www.excelurgy.skdfhsgjf.an.com/check/products.json`)
      .map((response) => response.json())
      .toPromise();
  }
}
