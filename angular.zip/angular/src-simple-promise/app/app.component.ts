import { Component } from '@angular/core';  
import {SearchService} from './services/search.service';

@Component({
  selector: 'app-root',
  template: `<h1>Hello</h1><br>{{obj|json}}`
})
export class AppComponent {
    obj:any;
    ss: SearchService;
    constructor(pss: SearchService){
        this.ss = pss;
        this.lsearch();
    }

    lsearch() {
       this.ss.search('a')
          .then((result) => {
        console.log('Result is ' + result);
      })
      .catch((error) => console.error('error is ' +error));

    }
}
