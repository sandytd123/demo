/* FOR DOCS ... MUST MATCH ClickMeComponent template
  <button (click)="onClickMe()">Click me!</button>
*/

import { Component } from '@angular/core';

@Component({
  selector: 'click-me',
  /*template: `
    <button (click)="onClickMe()">Click me!</button>
    {{clickMessage | uppercase }}`*/ 
    
    template: `
    <button (dblclick)="onClickMe()">Click me!</button>
    {{clickMessage}}`
})
export class ClickMeComponent1 {
  clickMessage = '';

  onClickMe() {
    this.clickMessage = 'You have doubleclicked!';
  }
}
