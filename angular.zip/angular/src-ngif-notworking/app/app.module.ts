
import { NgModule } from '@angular/core';


import { AppComponent, Employee } from './app.component';


@NgModule({
  declarations: [
    AppComponent
,Employee  ],
  imports: [
],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { 

constructor() {
	console.log('This is a priority level 1 error message...'); 
}

}
