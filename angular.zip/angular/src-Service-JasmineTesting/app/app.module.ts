import {BrowserModule} from '@angular/platform-browser';
import {NgModule}      from '@angular/core';

import {AppComponent}  from './app.component';
import { LanguagesService } from './services/lang.service';


@NgModule({
  imports: [     
        BrowserModule
  ],
  declarations: [
        AppComponent
  ],
  providers: [
      LanguagesService
  ],
  bootstrap: [
        AppComponent
  ]
})
export class AppModule { }
