package com.cts.stream;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Teststream {

	public static void main(String[] args) {
		Stream<String> emptystream = Stream.empty();
		System.out.println(emptystream);//Create Empty Stream
		
		Stream<String> stream1 = Stream.of("d","e","f");//Create Stream using 'of' method.
		Collection<Integer>collection = Arrays.asList(1,2,3);
		Stream<Integer>stream2 = collection.stream();//Using any collection also we can create the stream.
		
		Stream stream3 = Stream.of(23,"e",40.0f,false);
		
		String arr[] = new String[] {"aa","ba","ca"};
		Stream<String> streamofarrayfull = Arrays.stream(arr);
		Stream<String> streampart = Arrays.stream(arr,0,2);
		
		emptystream = Arrays.asList("a","b","c").stream();
		System.out.println(emptystream);
           stream1.forEach(s->System.out.println(s));
		
		stream2.forEach(s->System.out.println(s));
		
		stream3.forEach(s->System.out.println(s));
		streamofarrayfull.forEach(s->System.out.println(s));
		
		streampart.forEach(s->System.out.println(s));
	}
		
		
		
		/*
		 * List<Product> productsList = new ArrayList<Product>(); //Adding Products
		 * productsList.add(new Product(1,"HP Laptop",25000f)); productsList.add(new
		 * Product(2,"Dell Laptop",30000f)); productsList.add(new
		 * Product(3,"Lenevo Laptop",28000f)); 
		 * List<Float> productPriceList2 =
		 * productsList.stream().filter(p -> p.price >
		 * 20000).map(p->p.price).collect(Collectors.toList());
		 * System.out.println(productPriceList2);
		 */
		
		 /* Stream.iterate(1, element->element+1)  
	        .filter(element->element%5==0)  
	        .limit(5)  
	        .forEach(System.out::println);
		  */
	}

}
