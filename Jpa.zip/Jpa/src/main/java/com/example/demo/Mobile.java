package com.example.demo;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.boot.autoconfigure.domain.EntityScan;

@Entity
public class Mobile implements Serializable {
	@Id
	@GeneratedValue
	private int mobid;
	private String mobname;
	private String mobmodal;

	  public Mobile()
	  {
		  	  }

	public Mobile(int mobid, String mobname, String mobmodal) {
		super();
		this.mobid = mobid;
		this.mobname = mobname;
		this.mobmodal = mobmodal;
	}

	public int getMobid() {
		return mobid;
	}

	public void setMobid(int mobid) {
		this.mobid = mobid;
	}

	public String getMobname() {
		return mobname;
	}

	public void setMobname(String mobname) {
		this.mobname = mobname;
	}

	public String getMobmodal() {
		return mobmodal;
	}

	public void setMobmodal(String mobmodal) {
		this.mobmodal = mobmodal;
	}

	@Override
	public String toString() {
		return "Mobile [mobid=" + mobid + ", mobname=" + mobname + ", mobmodal=" + mobmodal + "]";
	}
	  
	  
	  
}


