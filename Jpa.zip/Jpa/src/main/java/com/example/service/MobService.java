package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.MobDaoImpl;
import com.example.demo.Mobile;

@Service
public class MobService implements MobServiceImpl {
  
	@Autowired
	private MobDaoImpl mobdao;
	@Override
	public List<Mobile> getAllMobile() {
		// TODO Auto-generated method stub
		return mobdao.findAll();
	}

}
