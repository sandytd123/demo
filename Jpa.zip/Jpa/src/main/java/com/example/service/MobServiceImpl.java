package com.example.service;

import java.util.List;

import com.example.demo.Mobile;



public interface MobServiceImpl {
	public List<Mobile> getAllMobile();
}
