package com.example.dao;

import org.hibernate.metamodel.model.convert.spi.JpaAttributeConverter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Mobile;
@Repository
public interface MobDaoImpl extends JpaRepository<Mobile, Integer>{

}
