package com.cts.modal;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="prod_detail")
@NamedQueries(
		{
		@NamedQuery(name="retriveall",query="from ProdDetail"),
		@NamedQuery(name="retrievecount",query="Select count(*) from ProdDetail")
		})
public class ProdDetail implements Serializable {
	@Id
	@Column(name="prodid")
	private int proid;
	@Column(name="prodname")
	private String prodname;
	@Column(name="prodprice")
	private int price;
	
	
	public ProdDetail() {
		
	}


	public ProdDetail(int proid, String prodname, int price) {
		super();
		this.proid = proid;
		this.prodname = prodname;
		this.price = price;
	}


	public int getProid() {
		return proid;
	}


	public void setProid(int proid) {
		this.proid = proid;
	}


	public String getProdname() {
		return prodname;
	}


	public void setProdname(String prodname) {
		this.prodname = prodname;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "ProdDetail [proid=" + proid + ", prodname=" + prodname + ", price=" + price + "]";
	}
	

}


