package com.cts.hib;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.modal.ProdDetail;

class App 
{
    public static void main( String[] args )
    {
    	 Configuration configuration=new Configuration().configure();
     	SessionFactory sf=configuration.buildSessionFactory();
     	Session session=sf.openSession();
		
		//  ProdDetail prod=new ProdDetail(2,"ac",100); 
		 // session.beginTransaction();
		/*
		 * String hql = "from ProdDetail p where p.proid =?"; Query q =
		 * session.createQuery(hql); q.setParameter(0, 1); List result = q.list();
		 * System.out.println(result);
		 */
		// session.save(prod); System.out.println(prod);
		// session.getTransaction().commit();
		/*
		 * ProdDetail prod=new ProdDetail(); prod.setProid(3); String hql =
		 * "from ProdDetail  p where p.proid = :proid"; List result
		 * =session.createQuery(hql).setProperties(prod).list();
		 * System.out.println(result);
		 */
		/*
		 * Query q=session.getNamedQuery("retriveall"); System.out.println(q.list());
		 * Query q1=session.getNamedQuery("retrievecount"); List l1=q1.list();
		 * System.out.println(l1);
		 */
     	Query q=session.createSQLQuery("select * from Employee");//native qry execution
		List l=q.list();

		Object[] l1=(Object[])l.get(0);
		System.out.println(l1);
		  session.close();
		 
     
     	
     	
    }
}
