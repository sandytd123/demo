import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplaycartComponent } from './displaycart/displaycart.component';

import { AddbuyerComponent } from './addbuyer/addbuyer.component';


const routes: Routes = [
  {path : 'displaycart' , component:DisplaycartComponent},
  
  {path:'addbuyer1',component:AddbuyerComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
