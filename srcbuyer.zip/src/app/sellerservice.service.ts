import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import{Observable}  from 'rxjs'
import { Search } from './search';
import { Cart, ViewcartItem } from './item';
import { buyer } from './addbuyer/buyerinfo';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  private baseUrl = 'http://localhost:8081/searchitem';

  constructor(private http: HttpClient) { }

  // getitem(searchstr:String):Observable<any>{
  //   let search : any;
  //   search = new Search(searchstr);
  //   console.log("str:"+searchstr);
  //   return this.http.post(`${this.baseUrl}`,search);
  // }
  getItems(itemname: string) : Observable<any> {
    console.log(itemname);

    return this.http.get(`${this.baseUrl}/${itemname}`);
  }

  addtocart(cart:Cart):Observable<any>{

    return this.http.post('http://localhost:8080/1/addcartitem',cart);
  }
  displaycartItem():Observable<any>{
    return this.http.get('http://localhost:8080/1/getallcartItem');
  }
  updatecartItem( update:ViewcartItem):Observable<any>{
    return this.http.post('/http://localhost:8080/1/updatecartItem',update);
  }
  addbuyer(buyer:buyer):Observable<any>{
    console.log("in service");
    return this.http.post(`http://localhost:8080/addbuyer`,buyer);
  }
}