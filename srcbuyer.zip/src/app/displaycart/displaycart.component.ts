import { Component, OnInit } from '@angular/core';
import { SearchService } from '../sellerservice.service';
import { ViewcartItem } from '../item';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {

  constructor(private dipalycartService:  SearchService) { }
  diaplaycart:ViewcartItem=new ViewcartItem();
  view:ViewcartItem[];

  ngOnInit(): void {
    this.dipalycartService.displaycartItem().subscribe(displayitem=>this.view=displayitem);
  }
   increment(view:ViewcartItem){
     view.quantity=view.quantity+1;
     this.dipalycartService.updatecartItem(view).subscribe(viewitem=>this.view=viewitem);

   }
   decrement(view:ViewcartItem){
     view.quantity=view.quantity-1;
     this.dipalycartService.updatecartItem(view).subscribe(viewitem=>this.view=viewitem);
   }



}
