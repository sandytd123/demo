package com.cts.dao;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.cts.model.ProductModel;

@Repository
public class ProductDao extends JdbcDaoSupport {
	
	public int  addproduct(ProductModel product)
	{
		int storedstatus=getJdbcTemplate().update("insert into product values(?,?,?,?)",new Object[] {product.getProdId(), product.getProdName(),product.getProdPrice(),product.getProdQuantity()});
	
 System.out.println(storedstatus);	
    return product.getProdId();
    
	}

	
	
	public int deleteproduct(int ProdId) {
		
		String query=("delete from the product detail where ProdId=?");
		
	}
	
	
}
