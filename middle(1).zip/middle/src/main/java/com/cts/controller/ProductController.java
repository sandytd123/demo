package com.cts.controller;

public class ProductController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
