package com.cts.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.main.buyer.Address;


@Repository
public interface AddressRespositary extends JpaRepository<Address, Integer> {

}
