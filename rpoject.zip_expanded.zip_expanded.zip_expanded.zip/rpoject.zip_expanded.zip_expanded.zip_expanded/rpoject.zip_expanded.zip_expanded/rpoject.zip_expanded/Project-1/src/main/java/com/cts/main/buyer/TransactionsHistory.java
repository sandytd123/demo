	package com.cts.main.buyer;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.cts.main.buyer.BuyerLogin;
@Entity
public class TransactionsHistory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionId;
	
	@ManyToOne
	@JoinColumn(name = "BuyerId")
	private BuyerLogin buyer;
	private String transactionType;
	private Date dateTime;
	private String remarks;
	private double transactionAmount;
	
	
	public TransactionsHistory(){
		
	}


	public TransactionsHistory(int transactionId, BuyerLogin buyer, String transactionType, Date dateTime,
			String remarks, double transactionAmount) {
		super();
		this.transactionId = transactionId;
		this.buyer = buyer;
		this.transactionType = transactionType;
		this.dateTime = dateTime;
		this.remarks = remarks;
		this.transactionAmount = transactionAmount;
	}


	public int getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public BuyerLogin getBuyer() {
		return buyer;
	}


	public void setBuyer(BuyerLogin buyer) {
		this.buyer = buyer;
	}


	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public Date getDateTime() {
		return dateTime;
	}


	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public double getTransactionAmount() {
		return transactionAmount;
	}


	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}


}