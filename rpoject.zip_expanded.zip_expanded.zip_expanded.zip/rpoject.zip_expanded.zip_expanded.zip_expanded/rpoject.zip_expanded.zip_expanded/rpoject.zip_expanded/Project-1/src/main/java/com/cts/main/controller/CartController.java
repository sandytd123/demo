package com.cts.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.main.buyer.CartItem;
import com.cts.main.service.CartService;

@RestController
public class CartController {
	@Autowired
	private CartService cartservice;
	@PostMapping(value="/{buyerId}/addcartitem")
	public CartItem addcartItem(@PathVariable(value= "buyerId") Integer buyerId,@RequestBody CartItem cartItem) {
		return cartservice.addcartitem(cartItem, buyerId);
	}
	@GetMapping(value="{buyerId}/getallcartItem")
	public List<CartItem> getallCartItem(@PathVariable(value="buyerId") Integer buyerId){
		return cartservice.getallCartItem(buyerId);
		
	}
	
	@DeleteMapping(value= "{buyerId}/deletebyid")
	public String deletecartItem(@PathVariable(value="cartItemId")Integer cartItemId){
		return cartservice.deletecartItem(cartItemId);
		
	}
	
	@PutMapping(value="{buyerId}/updatecartIem" )
	public List<CartItem> updatecartItem(@PathVariable(value="buyerId") Integer buyerId,@RequestBody CartItem cartItem){
		return updatecartItem(buyerId, cartItem);
		
	}
	@DeleteMapping(value = "/{buyerId}/deleteall")
	public String deleteAllItems(@PathVariable(value = "buyerId") Integer buyerId) {
		return cartservice.emptyCartItem(buyerId);
	}
	
	@PutMapping
	public String checkout(@PathVariable(value = "buyerId") Integer buyerId) {
		return cartservice.emptyCartItem(buyerId);

}
	
}

