package com.cts.main.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.cts.buyer.entity.BuyerInfo;
//import com.cts.buyer.entity.CartItems;
//import com.cts.buyer.entity.Item;
//import com.cts.buyer.entity.PurchaseHistory;
//import com.cts.buyer.entity.TransactionHistory;
import com.cts.main.buyer.BuyerLogin;
import com.cts.main.buyer.CartItem;
import com.cts.main.buyer.TransactionsHistory;
import com.cts.main.repo.BuyerRepositary;
import com.cts.main.repo.CartRespositary;



@Service
public class CartService{

@Autowired
private CartRespositary cartrepositary;
@Autowired
private BuyerRepositary buyerrepositary;
 

public CartItem addcartitem(CartItem cartItem, Integer buyerId) {
	  
	    Optional<BuyerLogin> buyer = buyerrepositary.findById(buyerId);
	    cartItem.setBuyerinfo(buyer.get());
	    return cartrepositary.save(cartItem);
	    
	    
}
	
    public String deletecartItem(Integer cartItemId) {
    	cartrepositary.deleteById(cartItemId);
    	return "deleted that cartItemId";
    }
    
    public List<CartItem> getallCartItem(){
    	List<CartItem> AllItems = cartrepositary.findAll();
    	return AllItems;
    	
    }
    
    public String emptyCartItem(Integer buyerId) {
    	cartrepositary.deleteAll();
    	return "Cart is Empty";
    }
     
    
   public List<CartItem> updateCartItem(CartItem cartItem, Integer cartItemId){
	   
	    Optional<CartItem> upadteItem=cartrepositary.findById(cartItemId);
	     if(upadteItem.isPresent())
	     {
	                CartItem Itemupdate=upadteItem.get();    
	                Itemupdate.setQuantity(cartItem.getQuantity());
	     }
	     return null;
	    	
   }
//   
//   public void checkout(Integer buyerId) {
//	   Double totalAmount = 0.00;
//		TransactionsHistory transaction = null;
//		PurchaseHistory purchase = null;
//		List<CartItems> cartItems = cartRepository.findAllCartItem(buyerId);
//		for(CartItems items : cartItems) {
//			Optional<Item> item = itemRepository.findById(items.getCartItemId());
//			totalAmount += item.get().getPrice();
//		}
//		Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
//		transaction  = new TransactionHistory();
//		transaction.setTransactionAmount(totalAmount);
//		transaction.setBuyer(buyer.get());
//		transaction.setTransactionType("debited");
//		transaction.setRemarks("paid");
//		
//		transactionRepository.save(transaction);
//		
//		for(CartItems items : cartItems) {
//			purchase = new PurchaseHistory();
//			purchase.setBuyer(buyer.get());
//			purchase.setTransaction(transaction);
//			purchase.setItemId(items.getItemId());
//			purchase.setRemarks("confirmed");
//			purchase.setNumberOfItems(items.getQuantity());
//			purchaseHistory.save(purchase);
//		}
//	}
   }
    
   
   



