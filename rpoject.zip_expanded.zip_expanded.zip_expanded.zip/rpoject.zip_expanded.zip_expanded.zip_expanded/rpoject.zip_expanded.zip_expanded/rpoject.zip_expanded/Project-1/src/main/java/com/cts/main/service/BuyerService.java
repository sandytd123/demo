package com.cts.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.main.buyer.BuyerLogin;
import com.cts.main.repo.AddressRespositary;
import com.cts.main.repo.BuyerRepositary;

@Service
public class BuyerService {
	@Autowired
	private BuyerRepositary buyerrepository;
	@Autowired
	private AddressRespositary addressrepository;

	public BuyerLogin addbuyer(BuyerLogin buyer) {
		//System.out.println(buyer);
		 addressrepository.save(buyer.getBuyerAddress());
		 return buyerrepository.save(buyer);
		 
	}
	
	

}
