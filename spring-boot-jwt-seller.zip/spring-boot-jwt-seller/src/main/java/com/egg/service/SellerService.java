package com.egg.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.egg.dao.SellerAddressRespositary;
import com.egg.dao.SellerDetailRepositary;
import com.egg.model.SellerDetail;

@Service
public class SellerService implements UserDetailsService{
	@Autowired
	private SellerAddressRespositary selleraddressrepositary;
	@Autowired
    private SellerDetailRepositary sellerdetailrepositary;
	
	public SellerDetail addsellerinfo(SellerDetail sellerinfo) {
		selleraddressrepositary.save(sellerinfo.getSelleradress());
		return sellerdetailrepositary.save(sellerinfo);
				
	}

	public SellerDetail findOne(String username) {
		
		return sellerdetailrepositary.findByUsername(username);
	}

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		SellerDetail seller  = sellerdetailrepositary.findByUsername(username);
		if(seller == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(seller.getUsername(), seller.getPassword(), getAuthority());
	}


	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_Seller"));
	}
}
