package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egg.model.SellerDetail;


@Repository
public interface SellerDetailRepositary extends JpaRepository<SellerDetail, Integer>{

	SellerDetail findByUsername(String username);
	
}
