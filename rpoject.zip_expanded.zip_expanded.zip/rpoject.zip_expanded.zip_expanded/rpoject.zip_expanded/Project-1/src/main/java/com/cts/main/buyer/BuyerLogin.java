package com.cts.main.buyer;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.cts.main.buyer.Address;
@Entity
public class BuyerLogin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int buyerId;
	@Column(name="name")
	private String username;
    private	String password;
	private String emailId;
	private Long mobileNumber;
	private Date dateTime;
	@OneToOne
	@JoinColumn(name="buyerAddress")
	private Address buyerAddress;
	
	public BuyerLogin()
	{
		
	}
	public BuyerLogin(int buyerId, String username, String password, String emailId, Long mobileNumber, Date dateTime,
			Address buyerAddress) {
		super();
		buyerId = buyerId;
		this.username = username;
		this.password = password;
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
		this.dateTime = dateTime;
		this.buyerAddress = buyerAddress;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		buyerId = buyerId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}

	public Address getBuyerAddress() {
		return buyerAddress;
	}

	public void setBuyerAddress(Address buyerAddress) {
		this.buyerAddress = buyerAddress;
	}
	@Override
	public String toString() {
		return "BuyerLogin [BuyerId=" + buyerId + ", username=" + username + ", password=" + password + ", emailId="
				+ emailId + ", mobileNumber=" + mobileNumber + ", dateTime=" + dateTime + ", buyerAddress="
				+ buyerAddress + "]";
	}


	}
	
	


	
	
	
	


