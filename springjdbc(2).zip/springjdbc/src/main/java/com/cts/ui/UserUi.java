package com.cts.ui;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.cts.model.User;
import com.cts.service.UserService;

public class UserUi {
		
	@Autowired
	private User user;
	@Autowired
	private UserService userService;
	
	public static void main(String args[]) {
		ApplicationContext ctx= new ClassPathXmlApplicationContext("spring.xml");
		UserUi ui=new UserUi();
		
		Integer userID;
		String  userName;
		Integer userAge;
		Long userMob;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Your Information:");
		System.out.println("Enter your Name >");
		userName = scan.next();
		System.out.println("Enter your Age >");
		userAge = scan.nextInt();
		System.out.println("Enter your Mobile Number >");
		userMob = scan.nextLong();
		int id=ui.userService.addUser(ui.user);
		System.out.println(id);
		
		
		
	}
}
