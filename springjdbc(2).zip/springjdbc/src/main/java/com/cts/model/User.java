package com.cts.model;

import org.springframework.stereotype.Component;

@Component
public class User {
	private Integer userID;
	private String userName;
	private Integer userAge;
	private Long userMobile;
	
	public User() {
		super();
	}
	public User(Integer userID, String userName, Integer userAge, Long userMobile) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.userAge = userAge;
		this.userMobile = userMobile;
	}
	
	public Integer getUserID() {
		return userID;
	}
	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getUserAge() {
		return userAge;
	}
	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}
	public Long getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(Long userMobile) {
		this.userMobile = userMobile;
	}	
}
