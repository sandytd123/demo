package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.UserDao;
import com.cts.model.User;

@Service
public class UserService {
	@Autowired
	private UserDao userdao;
	
	public int addUser(User user) {
		return userdao.addUser(user);
	}
}
