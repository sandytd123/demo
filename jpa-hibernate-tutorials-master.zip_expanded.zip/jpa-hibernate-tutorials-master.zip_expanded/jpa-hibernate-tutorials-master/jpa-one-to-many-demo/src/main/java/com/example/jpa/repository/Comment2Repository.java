package com.example.jpa.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.jpa.model.Comment1;
import com.example.jpa.model.Comment2;
@Repository
public interface Comment2Repository extends JpaRepository<Comment2, Long>{
	 Page<Comment2> findByPostId(Long postId, Pageable pageable);
	    Optional<Comment2> findByIdAndPostId(Long id, Long postId);

}
