package com.cts.seller;

public class SellerLogin {
   
	private int Id;
	private String UserName;
	private String Password;
	private String CompanyName;
	private long GSTIN;
    private	String BriefAboutCompany;
    private String PostalAddress;
    
    
	
	
}
