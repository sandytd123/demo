package com.cts.buyer;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.cts.buyer.Address;
@Entity
public class BuyerLogin {
	@Id
	@GeneratedValue
	private int BuyerId;
	private String Username;
    private	String Password;
	private String EmailId;
	private Long MobileNumber;
	private LocalDate DateTime;
	@OneToOne
	@JoinColumn(name="buyerAddress")
	private Address buyerAddress;
	
	public BuyerLogin()
	{
		
	}

	public BuyerLogin(int Buyerid, String username, String password, String emailId, Long mobileNumber, LocalDate dateTime,Address buyerAddress) {
		super();
		this.BuyerId = Buyerid;
		this.Username = username;
		this.Password = password;
		this.EmailId = emailId;
		this.MobileNumber = mobileNumber;
		this.DateTime = dateTime;
		this.buyerAddress=buyerAddress;
	}

	public int getBuyerId() {
		return BuyerId;
	}

	public void setBuyerId(int id) {
		BuyerId = id;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		EmailId = emailId;
	}

	public Long getMobileNumber() {
		return MobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		MobileNumber = mobileNumber;
	}

	public LocalDate getDateTime() {
		return DateTime;
	}

	public void setDateTime(LocalDate dateTime) {
		DateTime = dateTime;
	}
	
	

	public Address getBuyerAddress() {
		return buyerAddress;
	}

	public void setBuyerAddress(Address buyerAddress) {
		this.buyerAddress = buyerAddress;
	}

	@Override
	public String toString() {
		return "BuyerLogin [BuyerId=" + BuyerId + ", Username=" + Username + ", Password=" + Password + ", EmailId="
				+ EmailId + ", MobileNumber=" + MobileNumber + ", DateTime=" + DateTime + ", buyerAddress="
				+ buyerAddress + "]";
	}

	
	
	
	

}
