package com.cts.buyer;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class PurchaseHistory {
	
	@Id
	@GeneratedValue
	private int PurchaseHistoryId;
	private int BuyerId;
	private int sellerId;
	@ManyToOne
	@JoinColumn(name="TransactionId")
	private Transactions transaction;
	@ManyToOne
	@JoinColumn(name="BuyerId")
	private BuyerLogin buyerinfo;
	private int ItemId;
	private String NumberOfItems;
	private LocalDate DateTime;
	 
	public PurchaseHistory(){
		
	}

	public int getPurchaseHistoryId() {
		return PurchaseHistoryId;
	}

	public void setPurchaseHistoryId(int purchaseHistoryId) {
		PurchaseHistoryId = purchaseHistoryId;
	}

	public int getBuyerId() {
		return BuyerId;
	}

	public void setBuyerId(int buyerId) {
		BuyerId = buyerId;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public Transactions getTransaction() {
		return transaction;
	}

	public void setTransaction(Transactions transaction) {
		this.transaction = transaction;
	}

	public BuyerLogin getBuyerinfo() {
		return buyerinfo;
	}

	public void setBuyerinfo(BuyerLogin buyerinfo) {
		this.buyerinfo = buyerinfo;
	}

	public int getItemId() {
		return ItemId;
	}

	public void setItemId(int itemId) {
		ItemId = itemId;
	}

	public String getNumberOfItems() {
		return NumberOfItems;
	}

	public void setNumberOfItems(String numberOfItems) {
		NumberOfItems = numberOfItems;
	}

	public LocalDate getDateTime() {
		return DateTime;
	}

	public void setDateTime(LocalDate dateTime) {
		DateTime = dateTime;
	}

	@Override
	public String toString() {
		return "PurchaseHistory [PurchaseHistoryId=" + PurchaseHistoryId + ", BuyerId=" + BuyerId + ", sellerId="
				+ sellerId + ", transaction=" + transaction + ", buyerinfo=" + buyerinfo + ", ItemId=" + ItemId
				+ ", NumberOfItems=" + NumberOfItems + ", DateTime=" + DateTime + "]";
	}
	

}