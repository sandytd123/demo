package com.cts.buyer;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.cts.buyer.BuyerLogin;
@Entity
public class Transactions {
	@Id
	@GeneratedValue
	private int TransactionId;
	private int UserId;
	@ManyToOne
	@JoinColumn(name = "BuyerId")
	private BuyerLogin buyer;
	private String TransactionType;
	private LocalDate DateTime;
	private String remarks;
	
	
	public Transactions(){
		
	}


	public Transactions(int transactionId, int userId, BuyerLogin buyer, String transactionType, LocalDate dateTime,
			String remarks) {
		super();
		TransactionId = transactionId;
		UserId = userId;
		this.buyer = buyer;
		TransactionType = transactionType;
		DateTime = dateTime;
		this.remarks = remarks;
	}


	public int getTransactionId() {
		return TransactionId;
	}


	public void setTransactionId(int transactionId) {
		TransactionId = transactionId;
	}


	public int getUserId() {
		return UserId;
	}


	public void setUserId(int userId) {
		UserId = userId;
	}


	public BuyerLogin getBuyer() {
		return buyer;
	}


	public void setBuyer(BuyerLogin buyer) {
		this.buyer = buyer;
	}


	public String getTransactionType() {
		return TransactionType;
	}


	public void setTransactionType(String transactionType) {
		TransactionType = transactionType;
	}


	public LocalDate getDateTime() {
		return DateTime;
	}


	public void setDateTime(LocalDate dateTime) {
		DateTime = dateTime;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	@Override
	public String toString() {
		return "Transactions [TransactionId=" + TransactionId + ", UserId=" + UserId + ", buyer=" + buyer
				+ ", TransactionType=" + TransactionType + ", DateTime=" + DateTime + ", remarks=" + remarks + "]";
	}


	
	


	
	
	

}
