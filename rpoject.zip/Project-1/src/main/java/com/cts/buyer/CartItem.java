package com.cts.buyer;

public class CartItem {
	
	private Integer cartItemId;
	private Integer itemId;
	private Integer quantity;

}
