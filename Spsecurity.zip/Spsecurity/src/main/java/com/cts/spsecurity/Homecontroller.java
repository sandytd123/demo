package com.cts.spsecurity;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Homecontroller {
@RequestMapping("/home")
	public String getindexpage() {
   return "index";
}

@RequestMapping("/admin")
public String getadmin(Model m) {
	String msg="<h1> admin page</h1>";
	m.addAttribute("mymsg", msg);
	return "admin";
}
}