package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.ProductModel;
import com.cts.service.ProductService;

@RestController
public class ProductController {


		@Autowired
		ProductService prodservice;
		
		@RequestMapping(value="/product",method=RequestMethod.POST,produces="appication/json")
		public int addProduct(@RequestBody ProductModel product) {
			System.out.println(product);
			return prodservice.addproduct(product);
		}
		
	/*
	 * @RequestMapping(value="/delete/{prodId}",method=RequestMethod.DELETE) public
	 * ResponseEntity<ProductModel>deleteprod(@PathVariable("prodId") int prodId){
	 * int deletestatus=prodservice.deleteproduct(prodId); HttpHeaders headers=new
	 * HttpHeaders(); if(deletestatus==0) { headers.add("delete failed","failed" );
	 * return new ResponseEntity<ProductModel>(headers,HttpStatus.NOT_FOUND);
	 * 
	 * } headers.add("delete successfull",String.valueOf(prodId)); return new
	 * ResponseEntity<ProductModel>(headers,HttpStatus.OK);
	 * 
	 * }
	 * 
	 * @RequestMapping(value="/update/{prodId}",method = RequestMethod.PUT) public
	 * ResponseEntity<ProductModel>updateprod(@PathVariable("prodId")int
	 * prodId,@RequestBody ProductModel product ){ HttpHeaders headers=new
	 * HttpHeaders(); System.out.println(product); ProductModel
	 * checkproduct=prodservice.getbyId(prodId); System.out.println(checkproduct);
	 * if(checkproduct==null) { headers.add("update failed","failed"); return new
	 * ResponseEntity<ProductModel>(headers,HttpStatus.NOT_MODIFIED);
	 * 
	 * } headers.add("update successfull",String.valueOf(prodId)); return new
	 * ResponseEntity<ProductModel>(headers,HttpStatus.OK); }
	 * 
	 * 
	 * @RequestMapping(value="/getById/{prodId}",method = RequestMethod.GET) public
	 * ResponseEntity<ProductModel> getbyId (@PathVariable("prodId") int prodId){
	 * ProductModel product=prodservice.getbyId(prodId); HttpHeaders headers=new
	 * HttpHeaders(); if(product==null) { headers.add("search failed", "failed");
	 * return new ResponseEntity<ProductModel>(headers,HttpStatus.NOT_FOUND);
	 * 
	 * } headers.add("serach successfull",String.valueOf(prodId)); return new
	 * ResponseEntity<ProductModel>(product,headers,HttpStatus.OK); }
	 */

}


