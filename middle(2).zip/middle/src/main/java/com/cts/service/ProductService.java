package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.ProductDao;
import com.cts.model.ProductModel;

@Service
public class ProductService {
	@Autowired
	private ProductDao Dao;
	
	public int  addproduct(ProductModel product) {
		return Dao.addproduct(product);
	}
	/*
	 * public int deleteproduct(int ProdId) { return Dao.deleteproduct(ProdId); }
	 * public int updateproduct(ProductModel product) { return
	 * Dao.updateproduct(product); }
	 * 
	 * public ProductModel getbyId(int ProdId) { return Dao.getbyId(ProdId); }
	 */
}

