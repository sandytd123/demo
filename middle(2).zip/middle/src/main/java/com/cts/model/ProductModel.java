package com.cts.model;

import org.springframework.stereotype.Component;

@Component
public class ProductModel {
	
	private Integer ProdId;
	private String ProdName;
	private Integer ProdPrice;
    private Integer ProdQuantity;
	


 public ProductModel() {  
	 super();
		
    }

public ProductModel(Integer ProdId,String ProdName,Integer ProdPrice,Integer ProdQuantity) {
	super();
	this.ProdId=ProdId;
	this.ProdName=ProdName;
	this.ProdPrice=ProdPrice;
	this.ProdQuantity=ProdQuantity;
	

}

public int getProdId() {
	return ProdId;
}

@Override
public String toString() {
	return "ProductModel [ProdId=" + ProdId + ", ProdName=" + ProdName + ", ProdPrice=" + ProdPrice + ", ProdQuantity="
			+ ProdQuantity + "]";
}

public void setProdId(int prodId) {
	ProdId = prodId;
}

public String getProdName() {
	return ProdName;
}

public void setProdName(String prodName) {
	ProdName = prodName;
}

public float getProdPrice() {
	return ProdPrice;
}

public void setProdPrice(Integer prodPrice) {
	ProdPrice = prodPrice;
}

public int getProdQuantity() {
	return ProdQuantity;
}

public void setProdQuantity(int prodQuantity) {
	ProdQuantity = prodQuantity;
}



}