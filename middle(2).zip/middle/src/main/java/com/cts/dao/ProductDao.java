package com.cts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
//import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.cts.model.ProductModel;

@Repository
public class ProductDao  {
	@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;
	
	public void setDs(DataSource ds) {
		this.ds=ds;
		jdbc=new JdbcTemplate(this.ds);
	}
	

	
	public int  addproduct(ProductModel product)
	{
		
		jdbc=new JdbcTemplate(ds);
		int storedstatus=jdbc.update("insert into productdetail values(?,?,?,?)",new Object[] {product.getProdId(), product.getProdName(),product.getProdPrice(),product.getProdQuantity()});
	
		System.out.println(storedstatus);	
		return product.getProdId();
    
	}

	
	/*
	 * public int deleteproduct(int ProdId) { jdbc=new JdbcTemplate(ds); String
	 * query=("delete from the productdetail where ProdId=?"); int
	 * status=jdbc.update(query,new Object[] {ProdId}); return status; }
	 * 
	 * 
	 * public int updateproduct(ProductModel product) { jdbc=new JdbcTemplate(ds);
	 * String
	 * query="update productdetail SET ProdName=?,ProdQuantity=?,ProdPrice=? where ProdId=?"
	 * ; int status=jdbc.update(query,new Object[]
	 * {product.getProdName(),product.getProdPrice(),product.getProdQuantity(),
	 * product.getProdId()}); return status; }
	 * 
	 * public ProductModel getbyId(int ProdId) { jdbc=new JdbcTemplate(ds); String
	 * query="SELECT * from productdetail where prodId=?"; ProductModel
	 * product=(ProductModel)jdbc.queryForObject(query,new Object[] {ProdId}, new
	 * RowMapper<ProductModel>() {
	 * 
	 * @Override public ProductModel mapRow(ResultSet rs, int rowNum) throws
	 * SQLException { ProductModel product=new ProductModel();
	 * product.setProdId(rs.getInt(1)); product.setProdName(rs.getString(2));
	 * product.setProdPrice(rs.getInt(3)); product.setProdQuantity(rs.getInt(4));
	 * return product ; } }); System.out.println(product); return product;
	 * 
	 * }
	 */


}
