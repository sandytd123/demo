package com.cts.modal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity(name="order_detail")

public class Order implements Serializable {
	@Id
	@GeneratedValue
	private int ordid;
	private String ordcat;
	private String orddesc;
	private int ordquant;
	@OneToMany(mappedBy = "order")
	 private List<OrderItem> orderitem=new ArrayList();

	public List<OrderItem> getOrderitem() {
		return orderitem;
	}

	public void setOrderitem(List<OrderItem> orderitem) {
		this.orderitem = orderitem;
	}

	public int getOrdid() {
		return ordid;
	}

	public void setOrdid(int ordid) {
		this.ordid = ordid;
	}

	public Order() {
		
	}

	public Order( String ordcat, String orddesc, int ordquant) {
		super();
		
		this.ordcat = ordcat;
		this.orddesc = orddesc;
		this.ordquant = ordquant;
	}

	public String getOrdcat() {
		return ordcat;
	}

	public void setOrdcat(String ordcat) {
		this.ordcat = ordcat;
	}

	public String getOrddesc() {
		return orddesc;
	}

	public void setOrddesc(String orddesc) {
		this.orddesc = orddesc;
	}

	public int getOrdquant() {
		return ordquant;
	}

	public void setOrdquant(int ordquant) {
		this.ordquant = ordquant;
	}

	
}