package com.cts.modal;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class OrderItem implements Serializable {
	@Id
	@GeneratedValue
	private int orditemid;
	public int getOrditemid() {
		return orditemid;
	}

	public void setOrditemid(int orditemid) {
		this.orditemid = orditemid;
	}

	private String itemname;
	private String itemdesc;
	@ManyToOne
	private Order order;
	
	public OrderItem()
	{
		
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public OrderItem(String itemname, String itemdesc) {
		super();
		this.itemname = itemname;
		this.itemdesc = itemdesc;
	}

	@Override
	public String toString() {
		return "OrderItem [orditemid=" + orditemid + ", itemname=" + itemname + ", itemdesc=" + itemdesc + "]";
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public String getItemdesc() {
		return itemdesc;
	}

	public void setItemdesc(String itemdesc) {
		this.itemdesc = itemdesc;
	}

}
