package com.cts.Card;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.modal.Order;


public class App 
{
    public static void main( String[] args )
    {
    	
    		Configuration configuration = new Configuration().configure();
    		SessionFactory sf = configuration.buildSessionFactory();
    		Session session = sf.openSession();
    		
    		Order o1=new Order("electronics","tv",2);
    		session.beginTransaction();
    		session.save(o1);
    		
    		
    }
}
