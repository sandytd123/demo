package com.egg.service;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.AddressRespositary;
import com.egg.dao.BuyerRepositary;
import com.egg.model.BuyerLogin;



@Service
public class BuyerService implements UserDetailsService{
	@Autowired
	private BuyerRepositary buyerrepository;
	@Autowired
	private AddressRespositary addressrepository;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	public BuyerLogin addbuyer(BuyerLogin buyer) {
		//System.out.println(buyer);
		 addressrepository.save(buyer.getBuyerAddress());
		 buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
		 return buyerrepository.save(buyer);
		 
	}

	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerLogin buyer  = buyerrepository.findByUsername(username);
		if(buyer == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyer.getUsername(), buyer.getPassword(), getAuthority());
	}


	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_Buyer"));
	}


	public BuyerLogin findOne(String username) {
		return buyerrepository.findByUsername(username);
	}

	
	

}
