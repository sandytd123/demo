package com.cts.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.main.buyer.BuyerLogin;
import com.cts.main.repo.BuyerRepositary;

@Service
public class BuyerService {
	@Autowired
	private BuyerRepositary buyerrepository;
	
	public BuyerLogin addbuyer(BuyerLogin buyer) {
		return buyerrepository.save(buyer);
	}
	
	

}
