package com.cts.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cts.main.buyer.TransactionsHistory;
@Repository
public interface TransactionHistoryRepository extends JpaRepository<TransactionsHistory, Integer> {

}
