package com.cts.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.main.buyer.CartItem;

@Repository
public interface CartRespositary extends JpaRepository<CartItem, Integer> {

}
