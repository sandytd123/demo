package com.cts.main.buyer;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class PurchaseHistory {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int PurchaseHistoryId;
	private int BuyerId;
	private int sellerId;
	@ManyToOne
	@JoinColumn(name="TransactionId")
	private Transactions transaction;
	@ManyToOne
	private BuyerLogin buyerinfo;
	private int ItemId;
	private String NumberOfItems;
	private Date DateTime;
	 
	public PurchaseHistory(){
		
	}
	

	public PurchaseHistory(int purchaseHistoryId, int buyerId, int sellerId, Transactions transaction,
			BuyerLogin buyerinfo, int itemId, String numberOfItems, Date dateTime) {
		
		PurchaseHistoryId = purchaseHistoryId;
		BuyerId = buyerId;
		this.sellerId = sellerId;
		this.transaction = transaction;
		this.buyerinfo = buyerinfo;
		ItemId = itemId;
		NumberOfItems = numberOfItems;
		DateTime = dateTime;
	}


	public int getPurchaseHistoryId() {
		return PurchaseHistoryId;
	}

	public void setPurchaseHistoryId(int purchaseHistoryId) {
		PurchaseHistoryId = purchaseHistoryId;
	}

	public int getBuyerId() {
		return BuyerId;
	}

	public void setBuyerId(int buyerId) {
		BuyerId = buyerId;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public Transactions getTransaction() {
		return transaction;
	}

	public void setTransaction(Transactions transaction) {
		this.transaction = transaction;
	}

	public BuyerLogin getBuyerinfo() {
		return buyerinfo;
	}

	public void setBuyerinfo(BuyerLogin buyerinfo) {
		this.buyerinfo = buyerinfo;
	}

	public int getItemId() {
		return ItemId;
	}

	public void setItemId(int itemId) {
		ItemId = itemId;
	}

	public String getNumberOfItems() {
		return NumberOfItems;
	}

	public void setNumberOfItems(String numberOfItems) {
		NumberOfItems = numberOfItems;
	}

	public Date getDateTime() {
		return DateTime;
	}

	public void setDateTime(Date dateTime) {
		DateTime = dateTime;
	}

	@Override
	public String toString() {
		return "PurchaseHistory [PurchaseHistoryId=" + PurchaseHistoryId + ", BuyerId=" + BuyerId + ", sellerId="
				+ sellerId + ", transaction=" + transaction + ", buyerinfo=" + buyerinfo + ", ItemId=" + ItemId
				+ ", NumberOfItems=" + NumberOfItems + ", DateTime=" + DateTime + "]";
	}
	

}