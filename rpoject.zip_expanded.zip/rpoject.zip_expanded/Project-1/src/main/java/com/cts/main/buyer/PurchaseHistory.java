package com.cts.main.buyer;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class PurchaseHistory {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int purchaseHistoryId;
	private int buyerId;
	private int sellerId;
	@ManyToOne
	@JoinColumn(name="TransactionId")
	private Transactions transaction;
	@ManyToOne
	private BuyerLogin buyerinfo;
	private int itemId;
	private String numberOfItems;
	private Date dateTime;
	 
	public PurchaseHistory(){
		
	}

	public PurchaseHistory(int purchaseHistoryId, int buyerId, int sellerId, Transactions transaction,
			BuyerLogin buyerinfo, int itemId, String numberOfItems, Date dateTime) {
		super();
		this.purchaseHistoryId = purchaseHistoryId;
		this.buyerId = buyerId;
		this.sellerId = sellerId;
		this.transaction = transaction;
		this.buyerinfo = buyerinfo;
		this.itemId = itemId;
		this.numberOfItems = numberOfItems;
		this.dateTime = dateTime;
	}

	public int getPurchaseHistoryId() {
		return purchaseHistoryId;
	}

	public void setPurchaseHistoryId(int purchaseHistoryId) {
		this.purchaseHistoryId = purchaseHistoryId;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public Transactions getTransaction() {
		return transaction;
	}

	public void setTransaction(Transactions transaction) {
		this.transaction = transaction;
	}

	public BuyerLogin getBuyerinfo() {
		return buyerinfo;
	}

	public void setBuyerinfo(BuyerLogin buyerinfo) {
		this.buyerinfo = buyerinfo;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getNumberOfItems() {
		return numberOfItems;
	}

	public void setNumberOfItems(String numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}

	@Override
	public String toString() {
		return "PurchaseHistory [purchaseHistoryId=" + purchaseHistoryId + ", buyerId=" + buyerId + ", sellerId="
				+ sellerId + ", transaction=" + transaction + ", buyerinfo=" + buyerinfo + ", itemId=" + itemId
				+ ", numberOfItems=" + numberOfItems + ", dateTime=" + dateTime + "]";
	}
	 
	
}
	

	