package com.cts.main.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cts.main.buyer.BuyerLogin;
import com.cts.main.buyer.CartItem;
import com.cts.main.repo.BuyerRepositary;
import com.cts.main.repo.CartRespositary;



@Service
public class CartService{

@Autowired
private CartRespositary cartrepositary;
@Autowired
private BuyerRepositary buyerrepositary;
 

public CartItem addcartitem(CartItem cartItem, Integer buyerId) {
	  
	    Optional<BuyerLogin> buyer = buyerrepositary.findById(buyerId);
	    cartItem.setBuyerinfo(buyer.get());
	    return cartrepositary.save(cartItem);
	    
	    
}
	
    public String deletecartItem(Integer cartItemId) {
    	cartrepositary.deleteById(cartItemId);
    	return "deleted that cartItemId";
    }
    
    public List<CartItem> getallCartItem(){
    	List<CartItem> AllItems = cartrepositary.findAll();
    	return AllItems;
    	
    }
    
    public String emptyCartItem(Integer buyerId) {
    	cartrepositary.deleteAll();
    	return "Cart is Empty";
    }
     
    
   public List<CartItem> updateCartItem(CartItem cartItem, Integer cartItemId){
	   
	    Optional<CartItem> upadteItem=cartrepositary.findById(cartItemId);
	     if(upadteItem.isPresent())
	     {
	                CartItem Itemupdate=upadteItem.get();    
	                Itemupdate.setQuantity(cartItem.getQuantity());
	     }
	     return null;
	    	
   }
}

