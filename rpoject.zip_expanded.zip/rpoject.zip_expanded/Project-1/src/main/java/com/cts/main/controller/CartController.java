package com.cts.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.main.buyer.CartItem;
import com.cts.main.service.CartService;

@RestController
public class CartController {
	@Autowired
	private CartService cartservice;
	@PostMapping(value="{buyerId}/addcartitem")
	public CartItem addcartItem(@PathVariable(value= "buyerId") Integer buyerId,@RequestBody CartItem cartItem) {
		return cartservice.addcartitem(cartItem, buyerId);
	}

}
