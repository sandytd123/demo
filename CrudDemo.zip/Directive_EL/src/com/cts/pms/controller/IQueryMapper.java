package com.cts.pms.controller;

public interface IQueryMapper {
	public static final String PRODUCT_INSERT_QRY = "INSERT INTO Product values(?,?,?,?)";
	public static final String FIND_BY_ID_QRY = "SELECT * FROM productdata WHERE prodid=?";
	public static final String FIND_ALL_PRODUCTS_QRY = "SELECT * FROM productdata";
	public static final String UPDATE_PRODUCT = "UPDATE productdata SET prodname=?, price=?, qunt=? WHERE prodid=?";
	public static final String DELETE_PRODUCT = "DELETE FROM productdata WHERE prodid=?";
}
