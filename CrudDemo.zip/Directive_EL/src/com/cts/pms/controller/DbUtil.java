package com.cts.pms.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost:3306/product";
	static final String UN="root";
	static final String PASS="root";
	private static Connection conn=null;
	
	public static Connection getConnectionForDb() throws SQLException{
		try {
			Class.forName(JDBC_DRIVER);
		} catch (ClassNotFoundException e) {
		}
		conn=DriverManager.getConnection(DB_URL, UN, PASS);
		return conn;
	}
}




