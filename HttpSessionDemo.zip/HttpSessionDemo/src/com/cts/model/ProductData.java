package com.cts.model;

public class ProductData {
	private String name;
	private Integer price;
	private Integer quantity;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public ProductData(String name, Integer price, Integer quantity) {
		super();
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	public ProductData() {
		
	}
	@Override
	public String toString() {
		return "ProductData [name=" + name + ", price=" + price + ", quantity=" + quantity + "]";
	}	
	
	
}
