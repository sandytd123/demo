package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.model.ProductData;

/**
 * Servlet implementation class ProcessProduct
 */
@WebServlet("/productprocess.do")
public class ProcessProduct extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String prodName = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		
		ProductData pd = new ProductData(prodName,price,quantity);
		HttpSession session = request.getSession(true);/*used to carry data while we hop from 1 servlet to another. 
														While we move from one page to another the http tends to loose data.
														To solve the problem of http we use session.*/
		session.setAttribute("prod", pd);
		
		RequestDispatcher rd = request.getRequestDispatcher("servlet2");
		rd.forward(request, response);
	}
}
