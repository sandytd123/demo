package com.cts.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.model.ProductData;

@WebServlet("/servlet4")
public class servlet4 extends HttpServlet {
	private PrintWriter pw = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		pw = response.getWriter();
		
		HttpSession session = request.getSession();
		ProductData pd = (ProductData)session.getAttribute("prod");
		pw.println(pd);
		
		pw.println("<a href='servlet1'>link to servlet 1</a>");
		pw.println("<a href='logout'>logout</a>");
		}
}
