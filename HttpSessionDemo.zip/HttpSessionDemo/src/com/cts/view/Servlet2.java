package com.cts.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.model.ProductData;

@WebServlet("/servlet2")
public class Servlet2 extends HttpServlet {
	private PrintWriter pw = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		pw = response.getWriter();
		
		HttpSession session = request.getSession();/*used to carry data while we hop from 1 servlet to another. 
													While we move from one page to another the http tends to loose data.
													To solve the problem of http we use session.*/
		ProductData pd = (ProductData)session.getAttribute("prod");
		pw.println(pd);
		
		pw.println("<a href='servlet3'>link to servlet 3</a>");
	}
}
