/*Author: Janam Gupta
 *Description: Http Session Demo.
 *Created on : 19/01/2020
 */
package com.cts.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/servlet1")
public class Servelet1 extends HttpServlet {
	
	private PrintWriter pw = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		pw = response.getWriter();
		pw.println("<html><head><title>Page</title></head>");
		pw.println("<body>");
		pw.println(
				"<form action='productprocess.do' method='GET'>Product Name :<input type='text' name='name'/><br/> 	Product Quantity: <input type='text' name='quantity'/><br/>	Product Price: <input type='text' name='price'/><br/>		<input type='submit' value='store'/><br/>	</form>");
		pw.println("</body>");
		pw.println("</html>");
	}

}
