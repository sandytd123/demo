package com.cts.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.main.repo.SellerAddressRepositary;
import com.cts.main.repo.SellerDetailRepositary;
import com.cts.main.sellerentity.SellerDetail;

@Service
public class SellerService {
	@Autowired
	private SellerAddressRepositary selleraddressrepositary;
	@Autowired
    private SellerDetailRepositary sellerdetailrepositary;
	
	public SellerDetail addsellerinfo(SellerDetail sellerinfo) {
		selleraddressrepositary.save(sellerinfo.getSelleradress());
		return sellerdetailrepositary.save(sellerinfo);
				
	}
	
	
	
	
	

}
