package com.cts.main.sellerentity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class ProductSubCategory {
  
	
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	
	private int subcategoryId;
	private String subcategoryname;
	private Integer gstPercent;
	@ManyToOne
	private ProductCategory productcategory;
	private String briefAboutSubCategory;
	
	public ProductSubCategory() {
		
	}

	public ProductSubCategory(int subcategoryId, String subcategoryname, Integer gstPercent,
			ProductCategory productcategory, String briefAboutSubCategory) {
		super();
		this.subcategoryId = subcategoryId;
		this.subcategoryname = subcategoryname;
		this.gstPercent = gstPercent;
		this.productcategory = productcategory;
		this.briefAboutSubCategory = briefAboutSubCategory;
	}

	public int getSubcategoryId() {
		return subcategoryId;
	}

	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public String getSubcategoryname() {
		return subcategoryname;
	}

	public void setSubcategoryname(String subcategoryname) {
		this.subcategoryname = subcategoryname;
	}

	public Integer getGstPercent() {
		return gstPercent;
	}

	public void setGstPercent(Integer gstPercent) {
		this.gstPercent = gstPercent;
	}

	public ProductCategory getProductcategory() {
		return productcategory;
	}

	public void setProductcategory(ProductCategory productcategory) {
		this.productcategory = productcategory;
	}

	public String getBriefAboutSubCategory() {
		return briefAboutSubCategory;
	}

	public void setBriefAboutSubCategory(String briefAboutSubCategory) {
		this.briefAboutSubCategory = briefAboutSubCategory;
	}
	
	
}
