package com.cts.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cts.main.sellerentity.ProductDetail;
import com.cts.main.sellerentity.SerachProduct;
import com.cts.main.service.ProductDetailService;


@CrossOrigin("*")
@RestController
public class Productcontroller {
	
	
	@Autowired
	private ProductDetailService productdetailservice;
	
	@PostMapping(value="/additem/{sellerId}")
	public ProductDetail addProduct(@PathVariable(value= "sellerId") Integer sellerId,@RequestBody ProductDetail productdetail) {
		return productdetailservice.addproduct(productdetail, sellerId);}
	
	
	@GetMapping(value="/getallproduct/{sellerId}")
	public List<ProductDetail> getallItem(@PathVariable(value="sellerID") Integer sellerId){
		
		return productdetailservice.findallitem(sellerId);}
	
	@DeleteMapping(value= "/{itemId}/deletebyid")
	public String deleteItem(@PathVariable(value="itemId")Integer ItemId){
		System.out.println("hhhhhhh");
		return productdetailservice.deleteproduct(ItemId);
	}
	
	@PutMapping(value="{itemId}/updateItem" )
	public List<ProductDetail> updatecartItem(@PathVariable(value="itemId") Integer itemId,@RequestBody ProductDetail productdetail){
		return productdetailservice.updateproductItem(productdetail, itemId);
	}
	
	
	@GetMapping(value="/searchitem/{itemname}",produces = "application/json")
	public List<ProductDetail> getmatchingproduct(@PathVariable(value="itemname")@RequestBody SerachProduct itemname){
		System.out.println("bbbbbbbbbbb:"+itemname);
		return productdetailservice.getmatchingProduct(itemname);
	}
		
		
	
	

}
