package com.cts.main.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class SellerController {
  
	
	
}
