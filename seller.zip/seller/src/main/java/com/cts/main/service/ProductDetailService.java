package com.cts.main.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cts.main.repo.ProductDetailRepositary;
import com.cts.main.repo.SellerAddressRepositary;
import com.cts.main.repo.SellerDetailRepositary;
import com.cts.main.sellerentity.ProductDetail;
import com.cts.main.sellerentity.SellerDetail;
import com.cts.main.sellerentity.SerachProduct;

@Service
public class ProductDetailService {
	@Autowired
	private SellerDetailRepositary selllerdetailRepositary;
	@Autowired
	private SellerAddressRepositary selleraddressRepositary;
	@Autowired
	private ProductDetailRepositary productdetailRepositary;
	
	
	public ProductDetail addproduct(ProductDetail productdetail,Integer sellerId) {
		
	Optional<SellerDetail> sellerdetail	=selllerdetailRepositary.findById(sellerId);
	    //productdetail.setSellerdetail(sellerdetail.get());
	    return productdetailRepositary.save(productdetail);
	    
	}
	 public String deleteproduct(Integer ItemId) {
       productdetailRepositary.deleteById(ItemId);
    	return "deleted that product";
    	
	    }
	 
	  
	    public List<ProductDetail> findallitem(Integer sellerId){
	    	List<ProductDetail> AllItems = productdetailRepositary.findAllItem(sellerId);
	    			return AllItems;
	    	
    }
	 
	 public List<ProductDetail> updateproductItem(ProductDetail productdetail, Integer ItemId){
		   
		    Optional<ProductDetail> upadteItem=productdetailRepositary.findById(ItemId);
		     if(upadteItem.isPresent())
		     {
		                ProductDetail Itemupdate=upadteItem.get();    
		                Itemupdate.setStockNumber(productdetail.getStockNumber());
		                Itemupdate.setPrice(productdetail.getPrice());
		                Itemupdate.setItemName(productdetail.getItemName());
		                Itemupdate.setProductcategory(productdetail.getProductcategory());
		                Itemupdate.setProductsubcategory(productdetail.getProductsubcategory());
		                
		     }
		     return null;
		    	
	   }
	 
	     public List<ProductDetail> getmatchingProduct(SerachProduct itemname){
	    	 
	    	 return productdetailRepositary.getmatchingproduct(itemname.getItemname());
	     }
}
	
	


