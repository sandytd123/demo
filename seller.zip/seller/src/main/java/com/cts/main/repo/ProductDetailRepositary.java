package com.cts.main.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.cts.main.sellerentity.ProductDetail;
import com.cts.main.sellerentity.SerachProduct;
@Repository
public interface ProductDetailRepositary extends JpaRepository<ProductDetail, Integer> {
	@Query(value = "SELECT * FROM product_detail item WHERE item.seller_id = :sellerId", nativeQuery = true)
	public List<ProductDetail> findAllItem(@Param("sellerId")Integer sellerId); 
	@Query(value="from ProductDetail where itemName like %:itemname%")
	public List<ProductDetail> getmatchingproduct(@Param("itemname") String itemname);
}
