package com.cts.main.sellerentity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class ProductDetail {
	 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int itemid;
	private double price;
	private String itemName;
	private String description;
	private int stockNumber;
	private String remark;
	@ManyToOne
	private ProductCategory productcategory;
	@ManyToOne
	private ProductSubCategory productsubcategory;
		
	public ProductDetail() {
		
	}

	public ProductDetail(int itemid, double price, String itemName, String description, int stockNumber, String remark,
			ProductCategory productcategory, ProductSubCategory productsubcategory) {
		super();
		this.itemid = itemid;
		this.price = price;
		this.itemName = itemName;
		this.description = description;
		this.stockNumber = stockNumber;
		this.remark = remark;
		this.productcategory = productcategory;
		this.productsubcategory = productsubcategory;
	}

	public int getItemid() {
		return itemid;
	}

	public void setItemid(int itemid) {
		this.itemid = itemid;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getStockNumber() {
		return stockNumber;
	}

	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public ProductCategory getProductcategory() {
		return productcategory;
	}

	public void setProductcategory(ProductCategory productcategory) {
		this.productcategory = productcategory;
	}

	public ProductSubCategory getProductsubcategory() {
		return productsubcategory;
	}

	public void setProductsubcategory(ProductSubCategory productsubcategory) {
		this.productsubcategory = productsubcategory;
	}
	
	
	}


