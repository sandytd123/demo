import { Component, OnInit } from '@angular/core';


import { SearchService } from '../sellerservice.service';
import { buyer } from './buyerinfo';

@Component({
  selector: 'app-addbuyer',
  templateUrl: './addbuyer.component.html',
  styleUrls: ['./addbuyer.component.css']
})
export class AddbuyerComponent implements OnInit {
  buyer:buyer=new buyer();
  buyerinfo:any;

  constructor(private buyerService:  SearchService) { }
 

  ngOnInit(): void {
  }

  addbuyers(){
    this.buyerService.addbuyer(this.buyer).subscribe(()=> alert("signed in successful"));
    console.log("in buyer");
  }
  onsubmit(){
    this.addbuyers();

  }
  

}
