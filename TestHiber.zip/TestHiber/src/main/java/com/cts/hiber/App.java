
package com.cts.hiber;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
//import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cts.modal.Employee;

public class App 
{
    public static void main( String[] args )
    {
		/*
		 * Configuration configuration=new Configuration().configure();
		 * StandardServiceRegistryBuilder builder = new
		 * StandardServiceRegistryBuilder().applySettings(configuration.getProperties())
		 * ; SessionFactory factory =
		 * configuration.buildSessionFactory(builder.build()); Session session =
		 * factory.openSession();
		 */
        Configuration configuration=new Configuration().configure();
    	SessionFactory sf=configuration.buildSessionFactory();
    	Session session=sf.openSession();
    	session.beginTransaction();
    	Employee emp=(Employee)session.get(Employee.class,1001);
    	System.out.println(emp);
    	//t.commit();
    	//Transaction t1=session.beginTransaction();
    	emp.setDesig("opdate");
    	emp.setEmpname("ram");
    	//emp.setEmpId(1003);
       // emp.setEmpname("ship");
    //	emp.setDesig("admin");
    	session.update(emp);
    	//t.commit();
    	session.getTransaction().commit();
    	System.out.println(emp);
    	session.close();
       	
    }
    
}
