package com.cts.spjava;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Javaconfig {
	@Bean(name="countryobj")
	public Beanjava getcountry() {
		return new Beanjava("india");
	}

}
