package com.cts.spjava;

public class Beanjava {

	private String countryname;
	
	public Beanjava()
	{
		
	}

	public Beanjava(String countaryname) {
		super();
		this.countryname = countaryname;
	}

	public String getCountaryname() {
		return countryname;
	}

	public void setCountaryname(String countaryname) {
		this.countryname = countaryname;
	}

	@Override
	public String toString() {
		return "Beanjava [countryname=" + countryname + "]";
	}
	
	
}
