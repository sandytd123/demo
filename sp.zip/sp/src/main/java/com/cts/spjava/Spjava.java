package com.cts.spjava;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Spjava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext apcontext=new FileSystemXmlApplicationContext();
		Beanjava countryobj=(Beanjava)apcontext.getBean("countryobj");
		
		String countryname=countryobj.getCountaryname();
		System.out.println("country"+""+countryname);

	}



}