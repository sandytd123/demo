package com.cts.collectiondemo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.swing.text.html.HTMLDocument.Iterator;

public class TestCollection {

	public static void main(String[] args) {
	//list
		/*
		 * ArrayList<String> list=new ArrayList<String>();//Creating arraylist
		 * list.add("misti");//Adding object in arraylist list.add("Vijay");
		 * list.add("Rahul"); list.add("vijay");
		 */
		
		//list.forEach(System.out::print);
		 // for(String obj:list)  
			//    System.out.println(obj);
		
		 // Iterator itr=list.iterator();
		  //while(itr.hasNext()){
		   //System.out.println(itr.next());
		//user defined class object
		/*Student s1=new Student(101,"Shyam",18);  
		  Student s2=new Student(102,"Ravi",20);  
		  Student s3=new Student(103,"rahul",25);  
		  //creating arraylist  
		  ArrayList<Student> arraylist=new ArrayList<Student>();  
		  arraylist.add(s1);//adding Student class object  
		  arraylist.add(s2);  */
		
		   //System.out.println("Is ArrayList Empty: "+arraylist.isEmpty());//is empty method
		  
		//Updating an element at specific position  
         /* list.set(1,"ram");  
          System.out.println("After update: "+list.get(1));  
          
          System.out.println("An element at 2nd position: "+list.get(2));  
          for(String s:list){  
           System.out.println(s); */
		
		//hashset
	/*	HashSet<String> set=new HashSet();  
        set.add("One");    
        set.add("Two");    
        set.add("Three");   
        set.add("Four");  
        set.add("five");  
        set.forEach(System.out::println);  
        }  
		  
	{HashSet<String> set1=new HashSet();  
    set1.add("One");    
    set1.add("Two");    
    set1.add("Three");   
    set1.add("one");  
    set1.add("two");  
    set1.forEach(System.out::println);  
		}  

*/      //    set.remove("Ravi");  
//System.out.println("After invoking remove(object) method: "+set);
		
		/*TreeSet<String> treelist=new TreeSet();  
		  treelist.add("Ravi");  
		  treelist.add("Vijay");  
		  treelist.add("Ravi");  
		  treelist.add("Ajay");
		treelist.forEach(System.out::println);
	}*/
		
		/*
		 * Iterator i=treelist.descendingIterator(); while(i.hasNext()) {
		 * System.out.println(i.next());
		 */

		/*
		 * TreeSet<Integer> set=new TreeSet<Integer>(); set.add(24); set.add(66);
		 * set.add(12); set.add(15);
		 * System.out.println("Highest Value: "+set.pollFirst());
		 * System.out.println("Lowest Value: "+set.pollLast());
		 */
		//map
		/*
		 * Map<Integer,String> map=new HashMap<Integer,String>(); map.put(100,"Amit");
		 * map.put(101,"Vijay"); map.put(102,"Rahul"); //Returns a Set view of the
		 * mappings contained in this map map.entrySet() //Returns a sequential Stream
		 * with this collection as its source .stream() //Sorted according to the
		
		
		 */
		
		  /* SortedMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(100,"Amit");    
		      map.put(102,"Ravi");    
		      map.put(101,"Vijay");    
		      map.put(103,"Rahul");    
		      //Returns key-value pairs whose keys are less than the specified key.  
		      System.out.println("headMap: "+map.headMap(102));  
		      //Returns key-value pairs whose keys are greater than or equal to the specified key.  
		      System.out.println("tailMap: "+map.tailMap(102));  
		      //Returns key-value pairs exists in between the specified key.  
		      System.out.println("subMap: "+map.subMap(100, 102));    
		 }*/
		
		  
		  
	}
}





