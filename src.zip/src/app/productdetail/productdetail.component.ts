import { Component, OnInit,Input } from '@angular/core';
import { item, Cart, ViewcartItem } from '../item';
import { SearchService } from '../sellerservice.service';

@Component({
  selector: 'app-productdetail',
  templateUrl: './productdetail.component.html',
  styleUrls: ['./productdetail.component.css']
})

export class ProductdetailComponent implements OnInit {
  @Input() items: item;
  itemlist:any;
  cartlist:any;
  
  constructor(private dataService:  SearchService) { }

  ngOnInit(): void {
  }
 

  addtocart(itemId:number){
    let cart: Cart =new Cart();
    cart.itemId=itemId;

    cart.quantity=1;
    console.log(cart.itemId);
    this.dataService.addtocart(cart).subscribe(itemlist=>this.itemlist=itemlist);

  }
   
 
  


  
}
