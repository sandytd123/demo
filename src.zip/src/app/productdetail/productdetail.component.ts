import { Component, OnInit,Input } from '@angular/core';
import { item } from '../item';

@Component({
  selector: 'app-productdetail',
  templateUrl: './productdetail.component.html',
  styleUrls: ['./productdetail.component.css']
})
export class ProductdetailComponent implements OnInit {
  @Input() items: item;
  constructor() { }

  ngOnInit(): void {
  }

}
