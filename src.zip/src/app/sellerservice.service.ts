import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import{Observable}  from 'rxjs'
import { Search } from './search';
@Injectable({
  providedIn: 'root'
})
export class SearchService {

  private baseUrl = 'http://localhost:8081/searchitem';

  constructor(private http: HttpClient) { }

  getitem(searchstr:String):Observable<any>{
    let search : any;
    search = new Search(searchstr);
    console.log("str:"+searchstr);
    return this.http.post(`${this.baseUrl}`,search);
  }

  addtocart(){}
}