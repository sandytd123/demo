import { TestBed } from '@angular/core/testing';

import { SellermainService } from './sellermain.service';

describe('SellermainService', () => {
  let service: SellermainService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SellermainService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
