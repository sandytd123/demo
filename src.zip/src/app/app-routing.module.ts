import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddselleritemComponent } from './addselleritem/addselleritem.component';


const routes: Routes = [
 
  {path:'addselleritem',component:AddselleritemComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
