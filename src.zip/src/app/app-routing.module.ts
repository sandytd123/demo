import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { AddselleritemComponent } from './addselleritem/addselleritem.component';


const routes: Routes = [
  {path : 'displaycart' , component:DisplaycartComponent},
  {path:'addselleritem',component:AddselleritemComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
