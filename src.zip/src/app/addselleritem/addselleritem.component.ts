import { Component, OnInit } from '@angular/core';
import { SellermainService } from '../sellermain.service';
import { item } from '../item';

@Component({
  selector: 'app-addselleritem',
  templateUrl: './addselleritem.component.html',
  styleUrls: ['./addselleritem.component.css']
})
export class AddselleritemComponent implements OnInit {
  items:item=new item();
  price : number;
	itemName : String;
	description : String;
	stockNumber : number;
	remark : String;


  constructor(private dataservice:SellermainService) {
    
  }

  ngOnInit(): void {
  }
  additem(){
    this.items.itemName=this.itemName;
    this.items.price=this.price;
    this.items.stockNumber=this.stockNumber;
    this.items.remark=this.remark;
    this.items.description=this.description;
    this.dataservice.addproduct(this.items).subscribe(itemslist=>this.items=itemslist)
  }

}
