export class Search{
    constructor(private itemname : String){}
}