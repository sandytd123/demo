 export class Search{
     constructor(private searchStr : String){}
 }