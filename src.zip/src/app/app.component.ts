import { Component } from '@angular/core';
import{item} from './item';
import{SearchService} from './sellerservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'emart';

  items: item[];

  constructor(private dataService:  SearchService) { }

  ngOnInit() {
  }
  getitemproduct() {
    this.dataService.getitem("real")
      .subscribe(items => this.items = items);
  }
}

