import { Component, OnInit } from '@angular/core';
import { seller } from 'src/seller';
import { SellermainService } from '../sellermain.service';

@Component({
  selector: 'app-addseller',
  templateUrl: './addseller.component.html',
  styleUrls: ['./addseller.component.css']
})
export class AddsellerComponent implements OnInit {

  seller:seller=new seller();


  constructor(private sellerService:SellermainService) { }
 

  ngOnInit(): void {
  }

  addsellers(){
    this.sellerService.addseller(this.seller).subscribe(()=> alert("signed in successful"));
    console.log("in buyer");
  }
  onsubmit(){
    this.addsellers();

  }
}
