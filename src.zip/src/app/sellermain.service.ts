import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { item } from './item';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SellermainService {

  constructor(private http: HttpClient) { }

  addproduct(additem:item):Observable<any>{
     return this.http.post('http://localhost:8081/additem/1',additem);

  }
  deleteproduct(itemdelete:Object):Observable<any>{
    return this.http.delete('http://localhost:8081/additem/1',itemdelete);
  }
  updateitem(itemupdate:item):Observable<any>{
    console.log("uodate");
    return this.http.put('http://localhost:8081/additem/1',itemupdate);
  }
}
